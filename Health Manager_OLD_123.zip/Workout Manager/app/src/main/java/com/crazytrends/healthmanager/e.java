package com.crazytrends.healthmanager;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;

/* compiled from: lambda */
public final /* synthetic */ class e implements MaterialDialog.SingleButtonCallback {


    public static final /* synthetic */ e f4a = new e();

    private /* synthetic */ e() {
    }

    public final void onClick(MaterialDialog materialDialog, DialogAction dialogAction) {
        materialDialog.dismiss();
    }
}
