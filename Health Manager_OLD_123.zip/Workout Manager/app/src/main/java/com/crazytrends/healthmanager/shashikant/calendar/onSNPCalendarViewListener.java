package com.crazytrends.healthmanager.shashikant.calendar;

public interface onSNPCalendarViewListener {
    void onDateChanged(String str);

    void onDisplayedMonthChanged(int i, int i2, String str);
}
